package stubs;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;

public class ProcessLogs
{
  public static void main(String[] args) throws Exception
  {
    if (args.length != 2) 
    {
      System.out.printf("Usage: ProcessLogs <input dir> <output dir>\n");
      System.exit(-1);
    }
    Job monthjob = new Job();
    monthjob.setJarByClass(ProcessLogs.class);
    monthjob.setJobName("Process Logs");

    FileInputFormat.setInputPaths(monthjob, new Path(args[0]));
    FileOutputFormat.setOutputPath(monthjob, new Path(args[1]));

    monthjob.setMapperClass(LogMonthMapper.class);
    monthjob.setReducerClass(CountReducer.class);
    
    monthjob.setMapOutputKeyClass(Text.class);
    monthjob.setMapOutputValueClass(Text.class);

    monthjob.setOutputKeyClass(Text.class);
    monthjob.setOutputValueClass(IntWritable.class);

    monthjob.setNumReduceTasks(12);// set the number of reducers as 12
    monthjob.setPartitionerClass(MonthPartitioner.class);//set the Partitioner Class

    boolean success = monthjob.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}
