import sys
from pyspark import SparkContext
if __name__ == "__main__":
	sc = SparkContext()
	jpgcount = sc.textFile(sys.argv[1]).map(lambda lowerLine: lowerLine.lower()).filter(lambda isJpg: "jpg" in isJpg).count()
	print jpgcount
	sc.stop()